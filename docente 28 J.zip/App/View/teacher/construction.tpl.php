<div class="row" >
	<div class="col-md-12 content">
		<div class="panel panel-default">
		  	<div class="panel-body">
		  		<div class="container-fluid">
		  			<div class="col-md-12">	
						<div class="">
								<div class="text-center">	
									<h3 style=""><i class="fa fa-cog fa-spin fa-3x fa-fw"></i></h3>
									<h2 class="error-number">Ya Casi!</h2>
									<h4>Estamos creando la mejor experiencia de usuario para que la puedas disfrutar.</h4>
								</div>					
						</div>
					</div>
		  		</div>
		  	</div>
		</div>
	</div>
</div>