<!-- <h1 class="hidden-sm hidden-xs">Navigation</h1> -->
<div class="image">
	<img src="/Public/img/logo.gif" alt="" class="img-responsive">
</div>
<ul>
	<!-- Inicio -->
	<li class="active">
		<a href="/teacher">
			<span class="fa fa-dashboard" aria-hidden="true"></span>
			<span class="hidden-sm hidden-xs">Inicio</span>
		</a>
	</li>

	<!-- Evaluación -->
	<li>
		<a href="/teacher/Evaluation">
			<span class="fa fa-check" aria-hidden="true"></span>
			<span class="hidden-sm hidden-xs">Evaluación</span>
		</a>
	</li>

	<!-- Planilla -->
	<li>
		<a href="/teacher/sheets">
			<span class="fa fa-file-text-o" aria-hidden="true"></span>
			<span class="hidden-sm hidden-xs">Planillas</span>
		</a>
	</li>

	<!-- Estadisticas -->
	<li>
		<a href="/teacher/statistics" ">
			<span class="fa fa-line-chart" aria-hidden="true"></span>
			<span class="hidden-sm hidden-xs">Estadistica</span>
		</a>
	</li>

	<!-- Configuracion -->
	<li>
		<a href="/teacher/settings" ">
			<span class="fa fa-cog" aria-hidden="true"></span>
			<span class="hidden-sm hidden-xs">Configuración</span>
		</a>
	</li>
</ul>