<div class="row">
	<div class="col-md-12 content">
		<div class="panel panel-default">
		  	<div class="panel-heading">
		    	<h3 class="panel-title">Panel title</h3>
		  	</div>
		  	<div class="panel-body">
		    	Panel content
		  	</div>
		</div>
	</div>
</div>