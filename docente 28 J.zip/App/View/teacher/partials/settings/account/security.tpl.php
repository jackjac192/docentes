<div class="row" >
	<div class="col-md-12 content">
		<div class="panel panel-default">
		  	<div class="panel-body">
		  		<?php
		  		echo "TODO EL CODIGO AQUI Dir = ".__DIR__;
		  		?>
		  	</div>
		</div>
	</div>
</div>